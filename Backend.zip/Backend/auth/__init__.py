import pymysql
pymysql.install_as_MySQLdb()
pymysql.version_info = (2, 2, 6, 'final', 0)
